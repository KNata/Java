package Example3;

public class Program {

	public static void main(String[] args) {

		Paint frame = new Paint("Paint",500,400);
		frame.setVisible(true);
		
	}
}
