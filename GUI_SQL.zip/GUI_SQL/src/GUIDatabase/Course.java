package GUIDatabase;


public class Course {
	public Course(String name){
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String name = null;
}
